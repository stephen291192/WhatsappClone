const express = require ("express");
const mongoose = require("mongoose");
const {Rooms} = require('./dbRooms');
const Pusher = require("pusher");
const cors = require("cors");
const { Messages } = require("./dbMessages");


let SuccessMsg={
    "statusCode":"200",
    "statusMessage":"Success"
}

const app = express();
const port = process.env.PORT || 5000;
app.use(express.json());
app.use(cors());

// if you type text filed or enter automatically change and display package

const pusher = new Pusher({
  appId: "1658647",
  key: "0f51a0d62063d5f2e3be",
  secret: "d3fc58caad1d3566f491",
  cluster: "ap2",
  useTLS: true
});


const dbURL ="mongodb+srv://stephen291192:9789784349@chatapp.rrmxkla.mongodb.net/WhatsAppDB?retryWrites=true&w=majority";

mongoose.connect(dbURL);

const db= mongoose.connection;

db.once("open", () => {
  console.log("DB connected");

  const roomCollection = db.collection("rooms");
  const changeStream = roomCollection.watch();

  changeStream.on("change", (change) => {
    console.log(change);
    if (change.operationType === "insert") {
      const roomDetails = change.fullDocument;
      pusher.trigger("room", "inserted", roomDetails);
    } else {
      console.log("Not a expected event to trigger");
    }
  });

  const msgCollection = db.collection("messages");
  const changeStream1 = msgCollection.watch();

  changeStream1.on("change", (change) => {
    console.log(change);
    if (change.operationType === "insert") {
      const messageDetails = change.fullDocument;
      pusher.trigger("messages", "inserted", messageDetails);
    } else {
      console.log("Not a expected event to trigger");
    }
  });
});

// db.once("open",()=>{
//     console.log("db is connected")
// })

app.get("/",(req,res)=>{
    res.send("hello... I am Back-End");
})



app.get("/room/:id", async (req, res) => {
  
  try {
    const room = await Rooms.findOne({ _id: req.params.id });
    // console.log(room,"asdadasdasdasdadadas")
    if (room) {
      res.status(200).send(room);
    } else {
      res.status(404).send("Room not found");
    }
  } catch (error) {
    console.error("Error fetching room:", error);
    res.status(500).send("Internal Server Error");
  }
});

app.get("/messages/:id", async (req, res) => {
  try {
    const data = await Messages.find({ roomId: req.params.id }).exec();
    return res.status(200).send(data);
  } catch (err) {
    return res.status(500).send(err);
  }
});


app.post("/messages/new", async (req, res) => {
  const dbMessage = req.body;
  const data = new Messages(dbMessage);

  try {
    const savedMessage = await data.save();
    if (savedMessage) {
      res.send(SuccessMsg.statusMessage);
    }
  } catch (error) {
    console.error("Error saving message:", error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Create Group New message API
app.post("/group/create", async (req, res) => {
  const name = req.body.groupName;

  try {
      // Create a new Rooms document
      const data = new Rooms({ name });

      // Save the document to the database
      const savedata = await data.save();

      // Send a success response
      res.status(201).json(savedata);
  } catch (error) {
      // Handle errors
      console.error("Error creating group:", error);

      // Send an error response
      res.status(500).json({ error: "Internal server error" });
  }
});


  
//   Create All Details -  Rooms API
app.get("/all/rooms", async (req, res) => {

    try {
      const allData = await Rooms.find(); 
      res.json(allData); 
      console.log(allData,"allDataallData")
    } catch (error) {
      console.error("Error fetching data:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
    
  });


app.listen(port,()=>{
    console.log("Server is running")
});

