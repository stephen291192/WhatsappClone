// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// import {getAuth,GoogleAuthProvider} from 'firebase/auth'
import { getAnalytics } from "firebase/analytics";
import { getAuth, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAZoT3Jalvt7dO0d2ACUZPUasPbppH3_y0",
  authDomain: "whatapp-clone-43baa.firebaseapp.com",
  projectId: "whatapp-clone-43baa",
  storageBucket: "whatapp-clone-43baa.appspot.com",
  messagingSenderId: "100630837679",
  appId: "1:100630837679:web:5865a769fe4463d66c175a",
  measurementId: "G-5M9DNMY1W7"
};

// Initialize Firebase
let app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
let auth = getAuth();
let provider = new GoogleAuthProvider();

export {app,auth,provider};
