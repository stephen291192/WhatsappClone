import React from 'react'
import { FollowTheSignsOutlined } from '@mui/icons-material'
import { Button } from '@mui/material'
// import { auth,provider} from 'firebase/auth';
import{auth,provider} from '../../firebase';
import{signInWithPopup} from 'firebase/auth';
import {useStateValue} from '../ContextApi/StateProvider';
import{actionTypes} from'../ContextApi/Reducer';

function Login() {
    
    const [state,dispatch] = useStateValue();
    
    console.log("statestate",state)

    const signIn=()=>{
      signInWithPopup(auth,provider)

      .then((result) =>{
        // console.log(result)
        dispatch({
          type:actionTypes.SET_USER,
          user:result.user,
        })
      })
      .catch((err) =>{
        alert(err.message)
      });

    }

  return (
    <>
    <div className='login'>
        <div className='container_login'>
          <img src='https://png.pngtree.com/png-vector/20221018/ourmid/pngtree-whatsapp-mobile-software-icon-png-image_6315991.png' alt='Logo'/>
          <div className='login-text'>
            <h1> Sign in Whatsapp</h1>
            <Button onClick={signIn} className='LoginBtn'>
                Sign in Google
            </Button>
          </div>
        </div>

    </div>
   
    </>


  )
}

export default Login